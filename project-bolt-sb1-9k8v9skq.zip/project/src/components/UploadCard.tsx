import { useRef, useState, type ReactNode } from 'react';
import { UploadCloud, ImageIcon, X } from 'lucide-react';

interface UploadCardProps {
  title: string;
  subtitle?: string;
  caption?: string;
  icon?: ReactNode;
}

export default function UploadCard({ title, subtitle, caption, icon }: UploadCardProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const reset = () => {
    setPreview(null);
    setFileName('');
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <div className="rounded-2xl border-2 border-dashed border-accent-400/20 bg-cardbg p-6 transition-all hover:border-accent-400">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          {icon && (
            <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-accent-800/25 text-accent-400">
              {icon}
            </div>
          )}
          <div>
            <h4 className="font-semibold text-white text-sm">{title}</h4>
            {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
          </div>
        </div>
        {preview && (
          <button
            onClick={reset}
            className="flex items-center justify-center w-7 h-7 rounded-lg bg-primary-500 text-slate-400 hover:bg-red-900/30 hover:text-red-400 transition-colors"
            aria-label="Remove image"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <div
        onClick={() => !preview && inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          handleFile(e.dataTransfer.files[0]);
        }}
        className={`relative rounded-xl border-2 border-dashed transition-all cursor-pointer min-h-[200px] flex items-center justify-center overflow-hidden ${
          isDragging ? 'border-accent-400 bg-accent-800/15' : 'border-accent-400/15 bg-primary-500/50'
        }`}
      >
        {preview ? (
          <img src={preview} alt={fileName} className="w-full h-full object-contain max-h-[300px]" />
        ) : (
          <div className="text-center px-4 py-8">
            <div className="flex items-center justify-center w-14 h-14 mx-auto mb-3 rounded-2xl bg-accent-800/25 text-accent-400">
              <UploadCloud className="w-7 h-7" />
            </div>
            <p className="text-sm font-medium text-white">
              {isDragging ? 'Drop image here' : 'Click or drag to upload'}
            </p>
            <p className="text-xs text-slate-400 mt-1 flex items-center justify-center gap-1">
              <ImageIcon className="w-3 h-3" />
              PNG, JPG, SVG — screenshot or diagram
            </p>
          </div>
        )}
      </div>
      {caption && (
        <p className="mt-4 text-sm text-ink leading-relaxed">{caption}</p>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}
