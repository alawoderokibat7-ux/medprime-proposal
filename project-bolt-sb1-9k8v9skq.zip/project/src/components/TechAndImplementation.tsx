import { Cpu, Wrench, Boxes, Bot, MessageSquare, Mail, Slack, Table } from 'lucide-react';
import SectionWrapper from './SectionWrapper';

const techStack = [
  { icon: Boxes, label: 'n8n Engine', desc: 'Workflow orchestration & automation backbone' },
  { icon: Bot, label: 'Google Gemini AI', desc: 'Natural language understanding & reply drafting' },
  { icon: MessageSquare, label: 'WhatsApp Business API', desc: 'Inbound patient communication channel' },
  { icon: Mail, label: 'Gmail / Email Node', desc: 'Outbound lifecycle messaging & compliance' },
  { icon: Slack, label: 'Slack Notifications', desc: 'Real-time staff escalation alerts' },
  { icon: Table, label: 'Google Sheets Logging', desc: 'Audit trail & interaction records' },
];

const implementationSteps = [
  'Launch initial WhatsApp pilot for inbound query handling with a curated knowledge base.',
  'Designate channel leads for WhatsApp (inbound) and Email (outbound) to own quality and escalation.',
  'Test outbound email sequences — post-visit feedback, birthday greetings, and seasonal announcements.',
  'Conduct weekly log audits of Google Sheets interaction records to refine AI responses and identify gaps.',
];

export default function TechAndImplementation() {
  return (
    <SectionWrapper
      id="tech-infrastructure"
      eyebrow="Sections 6 & 7"
      title="Technical Infrastructure & Implementation"
      icon={<Cpu className="w-6 h-6" />}
    >
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-5">
            <Cpu className="w-5 h-5 text-accent-400" />
            <h3 className="text-lg font-bold text-white">Tech Stack</h3>
          </div>
          <div className="space-y-3">
            {techStack.map((tech, idx) => {
              const Icon = tech.icon;
              return (
                <div
                  key={idx}
                  className="flex items-center gap-4 rounded-xl border border-accent-400/20 bg-cardbg p-4 transition-all hover:border-accent-400/50 hover:shadow-md animate-fade-up"
                  style={{ animationDelay: `${idx * 0.06}s` }}
                >
                  <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-lg bg-accent-800/25 text-accent-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white text-sm">{tech.label}</h4>
                    <p className="text-xs text-ink">{tech.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-5">
            <Wrench className="w-5 h-5 text-accent-400" />
            <h3 className="text-lg font-bold text-white">Implementation Plan</h3>
          </div>
          <div className="rounded-2xl border border-accent-400/20 bg-cardbg p-6">
            <div className="space-y-5">
              {implementationSteps.map((step, idx) => (
                <div key={idx} className="flex gap-4 animate-fade-up" style={{ animationDelay: `${idx * 0.1}s` }}>
                  <div className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-accent-800 to-accent-400 text-primary-500 text-sm font-bold">
                    {idx + 1}
                  </div>
                  <div className="flex-1 pb-1">
                    <p className="text-sm text-ink leading-relaxed">{step}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 rounded-xl bg-gradient-to-br from-accent-800 to-accent-900 p-6 border border-accent-400/20">
            <h4 className="font-bold text-lg mb-2 text-white">Ready to Pilot</h4>
            <p className="text-sm text-slate-300 leading-relaxed">
              The infrastructure is modular — each channel can be deployed independently and scaled as the pilot
              matures. Start with WhatsApp inbound, then layer outbound email sequences.
            </p>
          </div>
        </div>
      </div>
    </SectionWrapper>
  );
}
