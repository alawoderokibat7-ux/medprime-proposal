import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-primary-500 text-white py-10 px-6 border-t border-accent-400/20">
      <div className="max-w-5xl mx-auto text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Heart className="w-5 h-5 text-accent-400" fill="currentColor" />
          <span className="font-display font-bold text-lg text-white">MedPrime Diagnostic Center</span>
        </div>
        <p className="text-sm text-slate-400 max-w-xl mx-auto">
          AI Patient Support &amp; Patient Engagement Automation — Operational Enhancement Proposal
        </p>
        <div className="mt-6 pt-6 border-t border-accent-400/10 text-xs text-slate-500">
          Confidential proposal prepared for internal review — September 2026
        </div>
      </div>
    </footer>
  );
}
