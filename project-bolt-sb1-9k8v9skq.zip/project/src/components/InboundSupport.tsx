import { MessageCircle, Bot, Send, AlertTriangle, UserCheck } from 'lucide-react';
import SectionWrapper from './SectionWrapper';
import UploadCard from './UploadCard';

const steps = [
  {
    icon: MessageCircle,
    label: 'Patient (Inbound)',
    description: 'Sends a WhatsApp message regarding prices, HMO, prep, or hours.',
    timing: 'Any time, no app needed',
    color: 'accent',
  },
  {
    icon: Bot,
    label: 'AI Support Agent',
    description: 'n8n queries the Price List & Knowledge Base to draft an instant reply.',
    timing: 'Seconds',
    color: 'primary',
  },
  {
    icon: Send,
    label: 'Patient (Response)',
    description: 'Receives direct, accurate answer via WhatsApp.',
    timing: 'Immediate',
    color: 'accent',
  },
  {
    icon: AlertTriangle,
    label: 'System Escalation',
    description: 'If human action is required (booking, payment, HMO check, complaint), logs details and posts a Slack alert.',
    timing: 'Immediate, when needed',
    color: 'primary',
  },
  {
    icon: UserCheck,
    label: 'Staff Resolution',
    description: 'Staff clicks the direct WhatsApp link in Slack to resolve the request.',
    timing: 'Per staff availability',
    color: 'accent',
  },
];

export default function InboundSupport() {
  return (
    <SectionWrapper
      id="inbound-support"
      eyebrow="Section 2"
      title="Inbound Support Flow"
      icon={<MessageCircle className="w-6 h-6" />}
    >
      <p className="text-ink text-base leading-relaxed mb-10">
        A five-step automated pipeline that handles routine WhatsApp inquiries end-to-end — from patient message to
        staff resolution — with intelligent escalation when human involvement is required.
      </p>

      <div className="relative">
        <div className="absolute left-5 md:left-6 top-2 bottom-2 w-0.5 bg-gradient-to-b from-accent-800/40 via-accent-400/40 to-accent-800/40" />

        <div className="space-y-5">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            const isAccent = step.color === 'accent';
            return (
              <div
                key={idx}
                className="relative flex gap-4 md:gap-6 animate-fade-up"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <div className="relative flex-shrink-0 z-10">
                  <div
                    className={`flex items-center justify-center w-11 h-11 md:w-12 md:h-12 rounded-xl border-2 bg-cardbg shadow-sm ${
                      isAccent ? 'border-accent-400 text-accent-400' : 'border-accent-800 text-accent-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span
                    className={`absolute -top-2 -right-2 flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
                      isAccent ? 'bg-accent-400 text-primary-500' : 'bg-accent-800 text-accent-400'
                    }`}
                  >
                    {idx + 1}
                  </span>
                </div>

                <div className="flex-1 rounded-xl border border-accent-400/20 bg-cardbg p-4 md:p-5 transition-all hover:border-accent-400/50 hover:shadow-md">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-white">{step.label}</h3>
                      <p className="text-sm text-ink mt-1 leading-relaxed">{step.description}</p>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap self-start ${
                        isAccent
                          ? 'bg-accent-400/15 text-accent-400 border border-accent-400/30'
                          : 'bg-accent-800/25 text-accent-300 border border-accent-800/40'
                      }`}
                    >
                      <svg className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <circle cx="12" cy="12" r="10" />
                        <polyline points="12 6 12 12 16 14" />
                      </svg>
                      {step.timing}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-12">
        <h3 className="text-sm font-semibold tracking-wider uppercase text-accent-400 mb-4">
          Inbound Architecture &amp; Interactive Visual
        </h3>
        <UploadCard
          title="Inbound Architecture & Interactive Visual"
          subtitle="Upload a workflow diagram or architecture screenshot"
          icon={<Bot className="w-5 h-5" />}
        />
      </div>
    </SectionWrapper>
  );
}
