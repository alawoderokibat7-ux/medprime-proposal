import { type ReactNode } from 'react';

interface SectionWrapperProps {
  id: string;
  eyebrow: string;
  title: string;
  icon?: ReactNode;
  children: ReactNode;
}

export default function SectionWrapper({ id, eyebrow, title, icon, children }: SectionWrapperProps) {
  return (
    <section id={id} className="py-16 md:py-20 px-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-start gap-4 mb-10">
          {icon && (
            <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-xl bg-accent-800/20 border border-accent-400/20 text-accent-400">
              {icon}
            </div>
          )}
          <div>
            <span className="text-xs font-semibold tracking-wider uppercase text-accent-400">{eyebrow}</span>
            <h2 className="text-2xl md:text-3xl font-bold font-display text-white mt-1">{title}</h2>
          </div>
        </div>
        {children}
      </div>
    </section>
  );
}
