import { ShieldCheck, ShieldX, UserCheck, Siren, Lock } from 'lucide-react';
import SectionWrapper from './SectionWrapper';

const safeguards = [
  {
    icon: ShieldX,
    title: 'No Medical Advice',
    description: 'Purely administrative; clinical queries trigger immediate human escalation.',
  },
  {
    icon: ShieldCheck,
    title: 'Strict Price Integrity',
    description: 'Live lookup against approved Price List only; never estimates or invents prices.',
  },
  {
    icon: UserCheck,
    title: 'Human-Controlled Approvals',
    description: 'Only staff/finance can confirm bookings or validate payments.',
  },
  {
    icon: Siren,
    title: 'Emergency Escalations',
    description: 'Urgent/crisis keywords trigger instant staff alerts with immediate crisis hotline delivery to the patient.',
  },
  {
    icon: Lock,
    title: 'Data Privacy',
    description: 'Minimal data collection (name & phone number only when required for staff follow-up).',
  },
];

export default function Safeguards() {
  return (
    <SectionWrapper
      id="safeguards"
      eyebrow="Section 5"
      title="Built-In Safeguards"
      icon={<ShieldCheck className="w-6 h-6" />}
    >
      <p className="text-ink text-base leading-relaxed mb-8">
        Every automation layer includes operational guardrails to ensure patient safety, data integrity, and appropriate
        human oversight.
      </p>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
        {safeguards.map((s, idx) => {
          const Icon = s.icon;
          const isWide = idx === 3;
          return (
            <div
              key={idx}
              className={`group rounded-2xl border border-accent-400/20 bg-cardbg p-6 transition-all hover:border-accent-400 hover:shadow-lg animate-fade-up ${
                isWide ? 'md:col-span-2 lg:col-span-1' : ''
              }`}
              style={{ animationDelay: `${idx * 0.08}s` }}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-accent-800/25 text-accent-400 group-hover:bg-accent-400 group-hover:text-primary-500 transition-colors">
                  <Icon className="w-5 h-5" />
                </div>
                <span className="inline-flex items-center px-3 py-1 rounded-full bg-accent-400 text-primary-500 text-xs font-bold tracking-wide uppercase">
                  {String(idx + 1).padStart(2, '0')}
                </span>
              </div>
              <h3 className="font-bold text-white mb-2">{s.title}</h3>
              <p className="text-sm text-ink leading-relaxed">{s.description}</p>
            </div>
          );
        })}
      </div>
    </SectionWrapper>
  );
}
