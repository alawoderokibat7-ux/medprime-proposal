import { Star, Cake, HeartPulse, Info } from 'lucide-react';
import SectionWrapper from './SectionWrapper';

const cards = [
  {
    icon: Star,
    title: 'Post-Visit Feedback & Reviews',
    description: 'Automated post-appointment check-ins sent via email, including direct Google Review links to build online reputation and capture patient satisfaction signals.',
    tags: ['Email Sequence', 'Google Reviews', 'Patient Satisfaction'],
  },
  {
    icon: Cake,
    title: 'Birthday & Milestone Celebrations',
    description: 'Personalized birthday greetings with optional wellness discount offers, strengthening patient loyalty and creating memorable touchpoints.',
    tags: ['Personalized', 'Wellness Discount', 'Loyalty'],
  },
  {
    icon: HeartPulse,
    title: 'Seasonal Health Announcements',
    description: 'Automated preventative health tips and holiday clinic updates — flu season reminders, adjusted hours, and relevant screening campaigns.',
    tags: ['Preventative Care', 'Holiday Hours', 'Health Tips'],
  },
];

export default function OutboundEngagement() {
  return (
    <SectionWrapper
      id="outbound-engagement"
      eyebrow="Section 3"
      title="Outbound Patient Engagement Workflows"
      icon={<Star className="w-6 h-6" />}
    >
      <div className="rounded-xl border border-accent-400/25 bg-accent-800/15 p-5 mb-8 flex items-start gap-4">
        <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-lg bg-accent-800/30 text-accent-400">
          <Info className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-semibold text-accent-400 text-sm mb-1">Compliance &amp; Deliverability</h3>
          <p className="text-sm text-ink leading-relaxed">
            Outbound messages use <strong className="text-white">Email</strong> rather than WhatsApp to maintain messaging compliance, avoid
            unsolicited messaging violations, and ensure reliable deliverability. Email provides a documented,
            opt-out-friendly channel for lifecycle communications.
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {cards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <div
              key={idx}
              className="group rounded-2xl border border-accent-400/20 bg-cardbg p-6 transition-all hover:border-accent-400 hover:shadow-xl animate-fade-up"
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-accent-800 to-accent-400 text-primary-500 mb-5 transition-transform group-hover:scale-110">
                <Icon className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-white text-lg mb-2">{card.title}</h3>
              <p className="text-sm text-ink leading-relaxed mb-4">{card.description}</p>
              <div className="flex flex-wrap gap-2">
                {card.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-1 rounded-md bg-primary-500 text-xs font-medium text-accent-400 border border-accent-400/20"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </SectionWrapper>
  );
}
