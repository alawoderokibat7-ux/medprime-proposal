import { Stethoscope, Sparkles } from 'lucide-react';

export default function Header() {
  return (
    <header className="relative overflow-hidden bg-primary-500 text-white border-b border-accent-400/20">
      <div className="absolute inset-0 opacity-15">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-accent-400 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-accent-800 blur-3xl" />
      </div>

      <div className="relative max-w-5xl mx-auto px-6 pt-16 pb-20 md:pt-24 md:pb-28">
        <div className="flex items-center gap-3 mb-8 animate-fade-up">
          <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-accent-400/15 border border-accent-400/30">
            <Stethoscope className="w-5 h-5 text-accent-400" strokeWidth={2} />
          </div>
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent-400/15 border border-accent-400/30 text-accent-400 text-xs font-semibold tracking-wider uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            MedPrime Diagnostic Center
          </span>
        </div>

        <h1 className="text-3xl md:text-5xl font-extrabold font-display leading-tight tracking-tight text-white animate-fade-up" style={{ animationDelay: '0.1s' }}>
          AI Patient Support &amp; Patient Engagement Automation
        </h1>

        <p className="mt-6 text-base md:text-lg text-slate-400 leading-relaxed max-w-2xl animate-fade-up" style={{ animationDelay: '0.2s' }}>
          Operational Enhancement Proposal: Streamlining Inbound Care Support &amp; Outbound Patient Engagement
        </p>

        <div className="mt-10 flex flex-wrap gap-3 animate-fade-up" style={{ animationDelay: '0.3s' }}>
          <div className="px-4 py-2 rounded-lg bg-cardbg border border-accent-400/20">
            <span className="text-xs text-slate-400 block">Prepared by</span>
            <span className="text-sm font-semibold text-white">Automation Team</span>
          </div>
          <div className="px-4 py-2 rounded-lg bg-cardbg border border-accent-400/20">
            <span className="text-xs text-slate-400 block">Date</span>
            <span className="text-sm font-semibold text-white">September 2026</span>
          </div>
          <div className="px-4 py-2 rounded-lg bg-cardbg border border-accent-400/20">
            <span className="text-xs text-slate-400 block">Status</span>
            <span className="text-sm font-semibold text-accent-400">Proposal Draft</span>
          </div>
        </div>
      </div>

      <div className="relative h-12 bg-gradient-to-b from-primary-500 to-transparent" />
    </header>
  );
}
