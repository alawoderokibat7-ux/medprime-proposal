import { LayoutGrid, MessageSquare, Clock3, Radio, ClipboardCheck, ScanLine } from 'lucide-react';
import SectionWrapper from './SectionWrapper';
import UploadCard from './UploadCard';

const visualCards = [
  {
    title: 'Real-Time Staff Escalation Alert (Slack)',
    caption: 'Automated Slack notification in #radiography-requests with direct wa.me patient link.',
    icon: MessageSquare,
  },
  {
    title: 'Instant Routine Pricing & Hours (WhatsApp)',
    caption: 'AI providing immediate opening hours, turnaround times, and pricing for Urinalysis, Scan, and H. pylori.',
    icon: Clock3,
  },
  {
    title: 'Radiographer Coordination & Detail Capture',
    caption: 'HSG inquiry prompting automated collection of patient name and contact details.',
    icon: Radio,
  },
  {
    title: 'Specialized Pre-Test Guidance',
    caption: 'Automated clinical preparation advice (abstinence instructions for Seminal Fluid Analysis).',
    icon: ClipboardCheck,
  },
  {
    title: 'Procedure Distinctions & Booking Triggers',
    caption: 'AI explaining Trans-Vaginal Scan vs. Folliculometry and routing appointment-only requests.',
    icon: ScanLine,
  },
];

export default function SystemArchitecture() {
  return (
    <SectionWrapper
      id="system-architecture"
      eyebrow="Section 4"
      title="Workflow Architecture Visuals"
      icon={<LayoutGrid className="w-6 h-6" />}
    >
      <p className="text-ink text-base leading-relaxed mb-8">
        Five representative workflow moments show how the automation moves from patient questions to accurate answers,
        staff coordination, and booking-ready handoffs.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-6 gap-6">
        {visualCards.map((card, index) => {
          const Icon = card.icon;
          const placement = index === 3 ? 'md:col-start-2' : index === 4 ? 'md:col-start-4' : '';

          return (
            <div key={card.title} className={`col-span-1 md:col-span-2 ${placement}`}>
              <UploadCard
                title={card.title}
                subtitle="Upload workflow screenshot or visual"
                caption={card.caption}
                icon={<Icon className="w-5 h-5" />}
              />
            </div>
          );
        })}
      </div>
    </SectionWrapper>
  );
}
