import { PhoneCall, Mail, Bot, Slack } from 'lucide-react';
import SectionWrapper from './SectionWrapper';

export default function ExecutiveContext() {
  return (
    <SectionWrapper
      id="executive-context"
      eyebrow="Section 1"
      title="Executive Context"
      icon={<Bot className="w-6 h-6" />}
    >
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-3">
          <p className="text-ink text-base md:text-lg leading-relaxed">
            Routine inbound patient inquiries — pricing questions, HMO coverage, preparation instructions, and operating
            hours — currently consume valuable front-desk staff time throughout the day. This proposal outlines a
            dual-channel automation strategy designed to deliver instant, accurate responses to patients while freeing
            staff to focus on care coordination and complex requests.
          </p>
        </div>

        <div className="group rounded-2xl border border-accent-400/20 bg-cardbg p-6 transition-all hover:border-accent-400 hover:shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent-800/25 text-accent-400">
              <PhoneCall className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-white">Inbound Support</h3>
          </div>
          <p className="text-sm text-ink leading-relaxed">
            WhatsApp + n8n — Instant 24/7 automated responses for routine queries, with automated Slack escalations for
            complex requests requiring human action.
          </p>
        </div>

        <div className="group rounded-2xl border border-accent-400/20 bg-cardbg p-6 transition-all hover:border-accent-400 hover:shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent-800/25 text-accent-400">
              <Mail className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-white">Outbound Engagement</h3>
          </div>
          <p className="text-sm text-ink leading-relaxed">
            Email + n8n — Automated lifecycle messaging for post-visit feedback, birthday greetings, and seasonal health
            announcements to keep patients connected.
          </p>
        </div>

        <div className="group rounded-2xl border border-accent-400/20 bg-cardbg p-6 transition-all hover:border-accent-400 hover:shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-accent-800/25 text-accent-400">
              <Slack className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-white">Smart Escalation</h3>
          </div>
          <p className="text-sm text-ink leading-relaxed">
            When human action is needed — bookings, payments, HMO checks, complaints — the system logs details and posts
            a Slack alert with a direct WhatsApp reply link for fast staff resolution.
          </p>
        </div>
      </div>
    </SectionWrapper>
  );
}
