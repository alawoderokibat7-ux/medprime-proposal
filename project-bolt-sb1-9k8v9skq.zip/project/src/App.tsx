import Header from '@/components/Header';
import ExecutiveContext from '@/components/ExecutiveContext';
import InboundSupport from '@/components/InboundSupport';
import OutboundEngagement from '@/components/OutboundEngagement';
import SystemArchitecture from '@/components/SystemArchitecture';
import Safeguards from '@/components/Safeguards';
import TechAndImplementation from '@/components/TechAndImplementation';
import Footer from '@/components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-slatebg">
      <Header />
      <main>
        <ExecutiveContext />
        <div className="h-px bg-accent-400/10" />
        <InboundSupport />
        <div className="h-px bg-accent-400/10" />
        <OutboundEngagement />
        <div className="h-px bg-accent-400/10" />
        <SystemArchitecture />
        <div className="h-px bg-accent-400/10" />
        <Safeguards />
        <div className="h-px bg-accent-400/10" />
        <TechAndImplementation />
      </main>
      <Footer />
    </div>
  );
}
